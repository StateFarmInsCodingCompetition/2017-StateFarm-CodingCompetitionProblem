package sf.codingcomp.blocks.solution;

import sf.codingcomp.blocks.StoragePolyBlock;

public class StoragePolyBlockImpl<T> extends PolyBlockImpl implements StoragePolyBlock<T> {

    @Override
    public T getValue() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void setValue(T value) {
        // TODO Auto-generated method stub

    }

}
