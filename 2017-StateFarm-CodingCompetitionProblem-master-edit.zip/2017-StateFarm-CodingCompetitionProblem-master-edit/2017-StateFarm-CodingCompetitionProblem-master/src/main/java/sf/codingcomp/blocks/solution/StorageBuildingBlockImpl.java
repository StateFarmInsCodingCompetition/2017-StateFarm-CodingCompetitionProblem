package sf.codingcomp.blocks.solution;

import sf.codingcomp.blocks.StorageBuildingBlock;

public class StorageBuildingBlockImpl<T> extends BuildingBlockImpl implements StorageBuildingBlock<T> {

    @Override
    public T getValue() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void setValue(T value) {
        // TODO Auto-generated method stub

    }

}
